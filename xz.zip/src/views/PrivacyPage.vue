<template>
  <main class="container mx-auto px-4 py-6">
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
      <!-- 头部横幅 -->
      <div class="bg-gray-50 py-8 px-6 border-b border-gray-200">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">隐私政策</h1>
        <p class="text-gray-600">最近更新日期：2023年10月1日</p>
      </div>
      
      <!-- 主要内容 -->
      <div class="p-6">
        <div class="prose max-w-none text-gray-700">
          <p class="mb-4">本隐私政策描述了校招直通车如何收集、使用、存储和保护您的个人信息。使用我们的服务，即表示您同意本隐私政策中描述的做法。请仔细阅读本政策。</p>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">1. 信息收集</h2>
            <p class="mb-3">我们收集的个人信息类型包括：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li><strong>注册信息</strong>：当您创建账户时，我们会收集您的姓名、电子邮件地址、电话号码、密码等信息。</li>
              <li><strong>个人资料信息</strong>：您在平台上提供的教育背景、工作经历、技能、求职意向等信息。</li>
              <li><strong>简历信息</strong>：您上传的简历中包含的个人详细信息。</li>
              <li><strong>使用数据</strong>：关于您如何使用我们的服务的信息，例如您浏览的页面、点击的链接、搜索的内容等。</li>
              <li><strong>设备信息</strong>：包括您的IP地址、浏览器类型、操作系统、设备标识符等。</li>
            </ul>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">2. 信息使用</h2>
            <p class="mb-3">我们使用收集的信息：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li>提供、维护和改进我们的服务</li>
              <li>为您推荐相关的职位和企业</li>
              <li>分析您的简历并提供优化建议</li>
              <li>处理您的申请，并向您提供相关的宣讲会通知</li>
              <li>与您沟通，包括发送服务通知、更新和安全警报</li>
              <li>分析用户行为，改进用户体验</li>
              <li>防止欺诈和滥用</li>
            </ul>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">3. 信息共享</h2>
            <p class="mb-3">我们可能在以下情况下共享您的个人信息：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li><strong>与招聘企业</strong>：当您申请职位或参加企业宣讲会时，我们会将您的相关信息共享给对应的招聘企业。</li>
              <li><strong>服务提供商</strong>：我们使用第三方服务提供商来帮助我们提供服务，这些提供商可能需要访问您的个人信息以提供服务。</li>
              <li><strong>法律要求</strong>：如果法律要求或为响应合法请求（如搜查令或法院命令），我们可能会共享您的信息。</li>
              <li><strong>业务转让</strong>：如果我们涉及合并、收购或资产出售，您的个人信息可能会作为该交易的一部分被转移。</li>
            </ul>
            <p>我们不会将您的个人信息出售给第三方。</p>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">4. 数据安全</h2>
            <p class="mb-3">我们采取多项措施保护您的个人信息：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li>使用加密技术保护数据传输</li>
              <li>实施访问控制机制，限制对个人信息的访问</li>
              <li>定期安全评估和漏洞扫描</li>
              <li>员工培训和合规审查</li>
            </ul>
            <p>尽管我们努力保护您的个人信息，但请注意，没有任何安全措施是绝对完美的。</p>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">5. 您的权利</h2>
            <p class="mb-3">您拥有以下与您的个人信息相关的权利：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li><strong>访问权</strong>：您可以要求获取我们持有的关于您的个人信息的副本。</li>
              <li><strong>更正权</strong>：如果您认为我们持有的关于您的信息不正确或不完整，您可以要求更正。</li>
              <li><strong>删除权</strong>：在某些情况下，您可以要求删除您的个人信息。</li>
              <li><strong>限制处理权</strong>：在某些情况下，您可以要求限制我们处理您的个人信息。</li>
              <li><strong>数据可携权</strong>：您可以要求我们以结构化、常用和机器可读的格式提供您的个人信息，或将其传输给另一个数据控制者。</li>
              <li><strong>反对权</strong>：您有权反对我们处理您的个人信息。</li>
            </ul>
            <p>要行使这些权利，请通过本政策末尾提供的联系方式与我们联系。</p>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">6. Cookie和类似技术</h2>
            <p class="mb-3">我们使用Cookie和类似技术来收集和存储信息，以提供更好的用户体验。这些技术帮助我们：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li>记住您的登录状态和偏好设置</li>
              <li>了解您如何使用我们的服务</li>
              <li>改善服务并提供个性化内容</li>
              <li>为您提供相关广告</li>
            </ul>
            <p>您可以通过浏览器设置控制Cookie的使用。但请注意，禁用Cookie可能会影响某些服务的功能。</p>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">7. 未成年人</h2>
            <p>我们的服务不面向16岁以下的未成年人。我们不会故意收集16岁以下儿童的个人信息。如果您是父母或监护人，并且您认为您的孩子向我们提供了个人信息，请联系我们，我们将采取措施从我们的系统中删除这些信息。</p>
          </section>
          
          <section class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-3">8. 政策变更</h2>
            <p>我们可能会不时更新本隐私政策。如有重大变更，我们会通过在我们的网站上发布通知或直接向您发送电子邮件来通知您。我们鼓励您定期查看本政策，以了解我们如何保护您的信息。</p>
          </section>
          
          <section>
            <h2 class="text-xl font-bold text-gray-800 mb-3">9. 联系我们</h2>
            <p>如果您对本隐私政策有任何疑问或关切，请通过以下方式与我们联系：</p>
            <ul class="list-disc pl-6 mb-4 space-y-2">
              <li>电子邮件：privacy@xiaozhaotongche.com</li>
              <li>电话：400-123-4567</li>
              <li>地址：北京市海淀区中关村软件园23号楼5层</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
export default {
  name: 'PrivacyPage'
}
</script> 